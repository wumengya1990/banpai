<template>
    <div class="SC_signIn">
        <top></top>
        <div class="SC_signInMain">
            <div class="SC_signInMainRight">
                <div class="signInRight_1">
                <h3><span>识别窗口</span></h3>
                <p>庆祝时前方摄像头，确保人脸图像清晰</p>
                <div class="authenticationBox"><img src="../../static/images/qindaoImg_07.jpg" alt=""></div>
                </div>

                <div class="signInRight_1">
                <h3><span>识别结果</span></h3>
                <div class="resultBox"><span>张敏</span><span>签到成功</span><span>09:15</span></div>
                </div>
            </div>
        
        <div class="SC_signInMainLeft">
            <h3><span>当前签到情况</span></h3>
            <div class="SC_signInMainLeft_1">
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em class="have">已签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em class="have">已签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em class="have">已签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
                <dl><dt><img src="../../static/images/userImg_03.png"></dt><dd><span>张敏</span><em>未签到</em></dd></dl>
            </div>
        </div>
        </div>
    </div>
</template>

<script>
import top from './top.vue'
export default {
    name:'signIn',
    components:{top}
}
</script>

<style>

</style>
