<template>
    <div class="SC_score">
        <h3></h3>
        <div></div>
    </div>
</template>

<script>
export default {
    name:'score'
}
</script>

<style>

</style>
