<template>
    <div class="SC_Screensaver">
        <div class="screenTop">
            <div class="collectiveImg">
                <img src="../../static/images/pinbaoImg_03.jpg">
            </div>
            <div class="screenTopRight">
            <div class="classSynopsis">
                <div class="classLogo"><img src="../../static/images/uerImg_07.png"></div>
                <h3>三年级一班</h3>
                <p><span>班主任：张婷</span><span>别名：尖刀班</span></p>
                <div class="clear"></div>
            </div>

            <div class="classMasterMessage">
                <h4><span>班主任寄语</span></h4>
                <div class="classMasterMessageCon">
                    <p>成功是你的人格资本。这世界并不会在意你的自尊。这世界指望你在自我感觉良好之前先要有所成就。成功是人生的最高境界，成功可以改变你的人格和尊严，自负是愚蠢的。</p>
                </div>
            </div>
            </div>
            <div class="clear"></div>
        </div>

        <div class="screenBottom">
            <div class="screenBottomBox">
                <h4><span>班级口号</span></h4>
                <div class="screenBottomBoxCon">
                    <p>每一次努力都是最优的亲近，每一滴汗水都是机遇的滋润。</p>
                </div>
            </div>
            <div class="screenBottomBox mgL30">
                <h4><span>班级座右铭</span></h4>
                <div class="screenBottomBoxCon">
                    <p>把你的目标列成表，因为你没有计划就不可能成功。不要整天没事干老胡思乱想，只有真正的行动才能拯救你！</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
name:"screensaver"
}
</script>

<style>

</style>
