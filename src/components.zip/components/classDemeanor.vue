<template>
    <div class="SC_classDemeanor mesBox">
        <top></top>
        <h3><span>班级风采</span></h3>
        <div class="demeanorList">
            <dl>
                <dt><router-link to="/classDemeanorCon"><img src="../../static/images/huandengImg_03.png"></router-link></dt>
                <dd>
                    <h4><router-link to="/classDemeanorCon">班级书法大赛</router-link></h4>
                    <p>班主任</p>
                    <p>2018-09-15</p>
                </dd>
            </dl>

            <dl>
                <dt><router-link to="/classDemeanorCon"><img src="../../static/images/huandengImg_03.png"></router-link></dt>
                <dd>
                    <h4><router-link to="/classDemeanorCon">班级书法大赛</router-link></h4>
                    <p>班主任</p>
                    <p>2018-09-15</p>
                </dd>
            </dl>

            <dl>
                <dt><router-link to="/classDemeanorCon"><img src="../../static/images/huandengImg_03.png"></router-link></dt>
                <dd>
                    <h4><router-link to="/classDemeanorCon">班级书法大赛</router-link></h4>
                    <p>班主任</p>
                    <p>2018-09-15</p>
                </dd>
            </dl>

            <dl>
                <dt><router-link to="/classDemeanorCon"><img src="../../static/images/huandengImg_03.png"></router-link></dt>
                <dd>
                    <h4><router-link to="/classDemeanorCon">班级书法大赛</router-link></h4>
                    <p>班主任</p>
                    <p>2018-09-15</p>
                </dd>
            </dl>

            <dl>
                <dt><router-link to="/classDemeanorCon"><img src="../../static/images/huandengImg_03.png"></router-link></dt>
                <dd>
                    <h4><router-link to="/classDemeanorCon">班级书法大赛</router-link></h4>
                    <p>班主任</p>
                    <p>2018-09-15</p>
                </dd>
            </dl>
            
            <div class="clear"></div>

        </div>
    </div>
</template>

<script>
import top from "./top.vue"
export default {
name:"classDemeanor",
components:{top}
}
</script>

<style>

</style>
