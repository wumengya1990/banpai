<template>
    <div class="SC_activity">
        <top></top>
        <div class="SC_activityList">
            <h3><span>班级活动</span></h3>
          <div class="SC_activityScroll">
            <div class="SC_activityBox">
                <div class="activityImg"><img src="../../static/images/huandengImg_03.png"></div>
                <div class="activityDescribe">
                    <div class="useImg"><img src="../../static/images/canyutouxiang_03.png"></div>
                    <div class="activityCon">
                        <h4>活动名称</h4>
                        <p>活动描述活动描述活动描述活动描述活动描述活动描述活动描述</p>
                        <div class="participants">
                            <span>参与人员</span>
                            <div class="participantsList">
                                <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                                <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                                <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                                <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                                <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                                <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                            </div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
                <a class="viewDetails" href="">查看详情</a>
            </div>

          <div class="SC_activityBox">
            <div class="activityImg"><img src="../../static/images/huandengImg_03.png"></div>
            <div class="activityDescribe">
              <div class="useImg"><img src="../../static/images/canyutouxiang_03.png"></div>
              <div class="activityCon">
                <h4>活动名称</h4>
                <p>活动描述活动描述活动描述活动描述活动描述活动描述活动描述</p>
                <div class="participants">
                  <span>参与人员</span>
                  <div class="participantsList">
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                  </div>
                </div>
              </div>
              <div class="clear"></div>
            </div>
            <a class="viewDetails" href="">查看详情</a>
          </div>

          <div class="SC_activityBox">
            <div class="activityImg"><img src="../../static/images/huandengImg_03.png"></div>
            <div class="activityDescribe">
              <div class="useImg"><img src="../../static/images/canyutouxiang_03.png"></div>
              <div class="activityCon">
                <h4>活动名称</h4>
                <p>活动描述活动描述活动描述活动描述活动描述活动描述活动描述</p>
                <div class="participants">
                  <span>参与人员</span>
                  <div class="participantsList">
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                  </div>
                </div>
              </div>
              <div class="clear"></div>
            </div>
            <a class="viewDetails" href="">查看详情</a>
          </div>

          <div class="SC_activityBox">
            <div class="activityImg"><img src="../../static/images/huandengImg_03.png"></div>
            <div class="activityDescribe">
              <div class="useImg"><img src="../../static/images/canyutouxiang_03.png"></div>
              <div class="activityCon">
                <h4>活动名称</h4>
                <p>活动描述活动描述活动描述活动描述活动描述活动描述活动描述</p>
                <div class="participants">
                  <span>参与人员</span>
                  <div class="participantsList">
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                  </div>
                </div>
              </div>
              <div class="clear"></div>
            </div>
            <a class="viewDetails" href="">查看详情</a>
          </div>

          <div class="SC_activityBox">
            <div class="activityImg"><img src="../../static/images/huandengImg_03.png"></div>
            <div class="activityDescribe">
              <div class="useImg"><img src="../../static/images/canyutouxiang_03.png"></div>
              <div class="activityCon">
                <h4>活动名称</h4>
                <p>活动描述活动描述活动描述活动描述活动描述活动描述活动描述</p>
                <div class="participants">
                  <span>参与人员</span>
                  <div class="participantsList">
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                  </div>
                </div>
              </div>
              <div class="clear"></div>
            </div>
            <a class="viewDetails" href="">查看详情</a>
          </div>

          <div class="SC_activityBox">
            <div class="activityImg"><img src="../../static/images/huandengImg_03.png"></div>
            <div class="activityDescribe">
              <div class="useImg"><img src="../../static/images/canyutouxiang_03.png"></div>
              <div class="activityCon">
                <h4>活动名称</h4>
                <p>活动描述活动描述活动描述活动描述活动描述活动描述活动描述</p>
                <div class="participants">
                  <span>参与人员</span>
                  <div class="participantsList">
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                  </div>
                </div>
              </div>
              <div class="clear"></div>
            </div>
            <a class="viewDetails" href="">查看详情</a>
          </div>

          <div class="SC_activityBox">
            <div class="activityImg"><img src="../../static/images/huandengImg_03.png"></div>
            <div class="activityDescribe">
              <div class="useImg"><img src="../../static/images/canyutouxiang_03.png"></div>
              <div class="activityCon">
                <h4>活动名称</h4>
                <p>活动描述活动描述活动描述活动描述活动描述活动描述活动描述</p>
                <div class="participants">
                  <span>参与人员</span>
                  <div class="participantsList">
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                  </div>
                </div>
              </div>
              <div class="clear"></div>
            </div>
            <a class="viewDetails" href="">查看详情</a>
          </div>

          <div class="SC_activityBox">
            <div class="activityImg"><img src="../../static/images/huandengImg_03.png"></div>
            <div class="activityDescribe">
              <div class="useImg"><img src="../../static/images/canyutouxiang_03.png"></div>
              <div class="activityCon">
                <h4>活动名称</h4>
                <p>活动描述活动描述活动描述活动描述活动描述活动描述活动描述</p>
                <div class="participants">
                  <span>参与人员</span>
                  <div class="participantsList">
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                  </div>
                </div>
              </div>
              <div class="clear"></div>
            </div>
            <a class="viewDetails" href="">查看详情</a>
          </div>

          <div class="SC_activityBox">
            <div class="activityImg"><img src="../../static/images/huandengImg_03.png"></div>
            <div class="activityDescribe">
              <div class="useImg"><img src="../../static/images/canyutouxiang_03.png"></div>
              <div class="activityCon">
                <h4>活动名称</h4>
                <p>活动描述活动描述活动描述活动描述活动描述活动描述活动描述</p>
                <div class="participants">
                  <span>参与人员</span>
                  <div class="participantsList">
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                    <a href=""><img src="../../static/images/canyutouxiang_03.png"></a>
                  </div>
                </div>
              </div>
              <div class="clear"></div>
            </div>
            <a class="viewDetails" href="">查看详情</a>
          </div>

            <div class="clear"></div>
          </div>
        </div>
    </div>
</template>

<script>
import top from './top.vue'
import $ from 'jquery'
export default {
name:'activity',
components:{top},
data(){
    return{

    }
},
  mounted(){
  this.participants();
  },
methods:{
    participants:function(){
      $(".participantsList").each(function () {
         let thisChildLength = $(this).find("a").length;
         console.log(thisChildLength);
         if(thisChildLength >= 4 ){
           $(this).find("a").css("margin","0 0 0 -10px");
           $(this).find("a").eq(0).css("margin",0);
           $(this).find("a:gt(4)").remove();
           $(this).find("a:last").append("<span>"+thisChildLength+"</span>");

         }
      })
    }
}
}
</script>

<style>

</style>
