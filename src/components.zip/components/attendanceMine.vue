<template>
    <div class="attendanceMine">
      <div class="SC_attendanceMine mesBox">
        <h3><span>我的考勤</span></h3>
        <div class="attendancetable">
          <div class="tableTop"><span>星期日</span><span>星期一</span><span>星期二</span><span>星期三</span><span>星期四</span><span>星期五</span><span>星期六</span></div>
          <div class="tableBody">
            <div>
              <h4>01</h4>
              <dl><dt>07:50</dt><dd>签到成功</dd></dl>
              <dl><dt>15:30</dt><dd>签到成功</dd></dl>
            </div>

            <div>
              <h4>01</h4>
              <dl><dt>07:50</dt><dd>签到成功</dd></dl>
              <dl><dt>15:30</dt><dd>签到成功</dd></dl>
            </div>

            <div>
              <h4>01</h4>
              <dl><dt>07:50</dt><dd>签到成功</dd></dl>
              <dl><dt>15:30</dt><dd>签到成功</dd></dl>
            </div>

            <div>
              <h4>01</h4>
              <dl><dt>07:50</dt><dd>签到成功</dd></dl>
              <dl><dt>15:30</dt><dd>签到成功</dd></dl>
            </div>

            <div>
              <h4>01</h4>
              <dl><dt>07:50</dt><dd>签到成功</dd></dl>
              <dl><dt>15:30</dt><dd>签到成功</dd></dl>
            </div>

            <div>
              <h4>01</h4>
              <dl><dt>07:50</dt><dd>签到成功</dd></dl>
              <dl><dt>15:30</dt><dd>签到成功</dd></dl>
            </div>

            <div>
              <h4>01</h4>
              <dl><dt>07:50</dt><dd>签到成功</dd></dl>
              <dl><dt>15:30</dt><dd>签到成功</dd></dl>
            </div>

            <div>
              <h4>01</h4>
              <dl><dt>07:50</dt><dd>签到成功</dd></dl>
              <dl><dt>15:30</dt><dd>签到成功</dd></dl>
            </div>

            <div>
              <h4>01</h4>
              <dl><dt>07:50</dt><dd>签到成功</dd></dl>
              <dl><dt>15:30</dt><dd>签到成功</dd></dl>
            </div>



          </div>
        </div>
      </div>
    </div>
</template>

<script>
    export default {
        name: "attendanceMine"
    }
</script>

<style scoped>

</style>
