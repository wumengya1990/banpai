<template>
    <div class="">
        
    </div>
</template>
<script>
export default {
     name: 'schoolIndex'
     
}
</script>

<style scoped>

</style>

