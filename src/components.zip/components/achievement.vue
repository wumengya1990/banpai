<template>
    <div class="SC_achievement mesBox">
      <h3><span>学业成绩</span></h3>
      <div class="SC_searchBox">
        <ul>
          <li>
            <em>选择学期</em>
            <select>
              <option>选择学期</option>
              <option>2018~2019第一学期</option>
              <option>2018~2019第二学期</option>
            </select>
          </li>
          <li>
            <em>考试范围</em>
            <select>
              <option>请选择范围</option>
              <option>2018~2019第一学期</option>
              <option>2018~2019第二学期</option>
            </select>

          </li>
          <li>
            <em>考试类型</em>
            <select>
              <option>请选择类型</option>
              <option>2018~2019第一学期</option>
              <option>2018~2019第二学期</option>
            </select>

          </li>
          <li>
            <em>考试名称</em>
            <select>
              <option>请选择名称</option>
              <option>2018~2019第一学期</option>
              <option>2018~2019第二学期</option>
            </select>

          </li>
          <li>
            <input type="button" value="查询"/>
          </li>

        </ul>
        <div class="clear"></div>
      </div>

      <div class="SC_achievementList">
        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>

        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>

        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>

        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>
        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>
        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>
        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>
        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>
        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>
        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>
        <div class="achievementBox">
          <h4>2018~2018学年第一学期期末考试六年级</h4>
          <div class="totalScore">总分<em>540</em></div>
          <div class="disciplineScore">
            <div class="scoreTop"><span>学科</span><span>分数</span><span>等级</span></div>
            <ul>
              <li><span>语文</span><span>90</span><span>优秀</span></li>
              <li><span>数学</span><span>90</span><span>优秀</span></li>
              <li><span>英语</span><span>90</span><span>优秀</span></li>
              <li><span>历史</span><span>90</span><span>优秀</span></li>
              <li><span>物理</span><span>90</span><span>优秀</span></li>
              <li><span>政治</span><span>90</span><span>优秀</span></li>
              <li><span>地理</span><span>90</span><span>优秀</span></li>
              <li><span>化学</span><span>90</span><span>优秀</span></li>
              <li><span>生物</span><span>90</span><span>优秀</span></li>
            </ul>
          </div>
        </div>

        <div class="clear"></div>
      </div>

      <div class="SC_backBut"><input type="button" value="返回"></div>

    </div>
</template>

<script>
  import $ from "jquery"
    export default {
        name: "achievement",
      data(){
          return{

          }
      },
      mounted(){
        this.shouDetailed();
      },
      methods:{
          shouDetailed:function () {
            $(".achievementBox").click(function () {
              $(this).find(".disciplineScore").toggle();
              event.stopPropagation();
            })
            $(".disciplineScore").click(function () {
              event.stopPropagation();
            })
          }
      }
    }
</script>

<style scoped>
  .el-input__inner{ height: 50px;}
</style>
