<template>
    <div class="appList">
      <div class="SC_LeftLogin">
        <div class="userImg"><img src="../../static/images/loginTX_03.png"></div>
        <p>点进登录</p>
        <div class="clear"></div>
      </div>
      <div class="SC_appList">
        <div class="appList_1">
          <h4><span>校园应用</span></h4>
          <div class="appBox">
            <dl><dt><img src="../../static/images/app01.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app02.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app03.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app04.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app05.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app06.png"></dt><dd>校园动态</dd></dl>
            <div class="clear"></div>
          </div>
        </div>

        <div class="appList_1">
          <h4><span>个人应用</span></h4>
          <div class="appBox">
            <dl><dt><img src="../../static/images/app07.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app08.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app09.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app10.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app11.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app12.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app07.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app08.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app09.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app10.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app11.png"></dt><dd>校园动态</dd></dl>
            <dl><dt><img src="../../static/images/app12.png"></dt><dd>校园动态</dd></dl>
            <div class="clear"></div>
          </div>
        </div>

      </div>

      <div class="SC_backBut">
        <input class="bt1" type="button" value="返回">
      </div>

    </div>
</template>

<script>
    export default {
        name: "appList"
    }
</script>

<style scoped>

</style>
